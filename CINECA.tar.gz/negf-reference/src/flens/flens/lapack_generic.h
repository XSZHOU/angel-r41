#ifndef FLENS_LAPACK_GENERIC_H
#define FLENS_LAPACK_GENERIC_H 1

#include <flens/densevector.h>
#include <flens/generalmatrix.h>

namespace flens {

} // namespace flens

#include <flens/lapack_generic.tcc>

#endif // FLENS_LAPACK_GENERIC_H
