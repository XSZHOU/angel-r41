#include <iostream>

using namespace std;

int
main()
{
    cout << "Hallo world!" << endl;
    cerr << "Here are news from cerr!" << endl;
}
