#include <poisson2d.h>

namespace flens {
    
Poisson2D::Poisson2D()
{
}
 
Poisson2D::Poisson2D(int _rh)
    : rh(_rh) 
{
}

} // namespace flens